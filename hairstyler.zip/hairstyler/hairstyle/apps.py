from django.apps import AppConfig


class HairstyleConfig(AppConfig):
    name = 'hairstyle'

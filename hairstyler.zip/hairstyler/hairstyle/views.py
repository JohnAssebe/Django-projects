from django.shortcuts import render
from .models import Hairstyle
# Create your views here.
def index(request):
    hairstyles=Hairstyle.objects.all()
    return render(request,'index.html',{'hairstyles':hairstyles})
def about(request):
    return render(request,'about.html')
def contact(request):
    return render(request,'contact.html')
def hairstyle(request):
    return render(request,'hairstyle.html')
def news(request):
    return render(request,'news.html')